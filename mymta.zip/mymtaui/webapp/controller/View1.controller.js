sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/table/Table"
], function (Controller, Table) {
	"use strict";

	return Controller.extend("com.epiuse.mymtaui.controller.View1", {
		onInit: function () {
			var oModel = new sap.ui.model.odata.ODataModel("/service/myeuro.xsodata", true);
			var oTable = new sap.ui.table.Table({title: "Countries"});
			oTable.addColumn(new sap.ui.table.Column({label:"Country Name", template: "name"}));
			oTable.setModel(oModel);
			oTable.bindRows("/myeuro");
			this.getView().byId("page").addContent(oTable);
			
			var aURL = "/service/myeuro.xsodata/myeuro";
			var handleSuccess = (function (oData) {
				oData.d.count = oData.d.results.length;
				debugger;
			}).bind(this); 
			
			var handleError = (function(XMLHttpRequest, textStatus, errorThrown){
				debugger;
			}).bind(this);

			jQuery.ajax({
				url: aURL,
				method: 'GET',
				dataType: 'json',
				async: false,
				crossDomain: true,
				success: handleSuccess,
				error: handleError
			});
		}
	});
});